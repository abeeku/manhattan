from stegano import lsb
from faker import Faker
import sys
fake = Faker('it_IT')
lines = []
while True:
    line = input()
    if line:
        lines.append(line)
    else:
        break
text = '\n'.join(lines)
secret = lsb.hide(sys.argv[1],text );
secret.save("./"+fake.name().replace(" ","_")+".png")
