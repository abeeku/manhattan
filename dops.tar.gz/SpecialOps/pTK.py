import base64
import os
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from stegano import lsb
from cryptography.fernet import Fernet
from datetime import datetime
from faker import Faker
import sys, getpass
#password_provided =  # This is input in the form of a string
password = getpass.getpass("speak f and e>").encode() # Convert to type bytes
salt = b'\xf5\xc5\xb2\xb2-a\x9e(\x1dO\xfb5\r\x9a\r\xa4' # CHANGE THIS - recommend using a key from os.urandom(16), must be of type bytes
kdf = PBKDF2HMAC(
    algorithm=hashes.SHA256(),
    length=32,
    salt=salt,
    iterations=100000,
    backend=default_backend()
)
key = base64.urlsafe_b64encode(kdf.derive(password))
print("-\t-\t-\t-\t-\t-\n")
fake = Faker('it_IT')

lines = []
lines.append(f"\t\t[{datetime.now()}]\t\t")
while True:
    line = input()
    if line:
        lines.append(line)
    else:
        break

f= Fernet(key)
text = f.encrypt(('\n'.join(lines)).encode())
secret = lsb.hide(sys.argv[1],text.decode() );
secret.save("./"+fake.name().replace(" ","_")+".png")
